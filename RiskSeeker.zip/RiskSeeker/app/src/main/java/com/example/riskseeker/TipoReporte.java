package com.example.riskseeker;

public class TipoReporte{

}
